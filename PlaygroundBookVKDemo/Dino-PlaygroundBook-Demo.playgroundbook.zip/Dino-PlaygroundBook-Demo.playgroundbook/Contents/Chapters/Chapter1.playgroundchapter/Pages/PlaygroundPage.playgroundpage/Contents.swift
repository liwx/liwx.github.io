//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

//#-hidden-code
//https://developer.apple.com/library/archive/documentation/Xcode/Conceptual/swift_playgrounds_doc_format/Prose.html#//apple_ref/doc/uid/TP40017343-CH71-SW1
//#-end-hidden-code

//#-code-completion(everything, hide)
//#-code-completion(identifier, show, speakAction())

//: 这里是代码注释--单行注释

/*:
    注释第一行----多行注释
    第二行
    第三行
 */

let str = "Hello, vipkid~"
