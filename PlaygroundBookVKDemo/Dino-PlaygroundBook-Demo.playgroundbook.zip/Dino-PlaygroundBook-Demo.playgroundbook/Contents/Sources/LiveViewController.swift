//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  An auxiliary source file which is part of the book-level auxiliary sources.
//  Provides the implementation of the "always-on" live view.
//

import UIKit
//import PlaygroundSupport
import PlaygroundSupport
import AVFoundation

@objc(Book_Sources_LiveViewController)
public class LiveViewController: UIViewController, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {
    
    public func liveViewMessageConnectionOpened() {
        // Implement this method to be notified when the live view message connection is opened.
        // The connection will be opened when the process running Contents.swift starts running and listening for messages.
    }
 

    
    public func liveViewMessageConnectionClosed() {
        // Implement this method to be notified when the live view message connection is closed.
        // The connection will be closed when the process running Contents.swift exits and is no longer listening for messages.
        // This happens when the user's code naturally finishes running, if the user presses Stop, or if there is a crash.
    }
    
    
    public func receive(_ message: PlaygroundValue) {
        // Implement this method to receive messages sent from the process running Contents.swift.
        // This method is *required* by the PlaygroundLiveViewMessageHandler protocol.
        // Use this method to decode any messages sent as PlaygroundValue values and respond accordingly.
        
        guard case .string(_) = message else {return}
        
        doSpeak()
        
    }
    
    var dinoImgV:UIImageView!
    var player:AVAudioPlayer!
    
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        dinoImgV = UIImageView.init(frame: CGRect.init(x: 0, y: 0, width: 100, height: 100))
        let img1 = UIImage(named: "gemstore_dinobg1.tiff")
        let img2 = UIImage(named: "gemstore_dinobg2.tiff")
        dinoImgV.image = img1
        dinoImgV.animationImages = [img1!, img2!]
        dinoImgV.animationDuration = 0.7
        dinoImgV.animationRepeatCount = 3
        view.addSubview(dinoImgV)

        let url = Bundle.main.path(forResource: "audio", ofType: "mp3")
        try! player = AVAudioPlayer.init(contentsOf: URL.init(fileURLWithPath: url!))
        
    }
    
    public override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        dinoImgV.center = view.center
        dinoImgV.sizeToFit()
    }
    
    func doSpeak() {
        dinoImgV.startAnimating()
        player.play()
    }
    
}
